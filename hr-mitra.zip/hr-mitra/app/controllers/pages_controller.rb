class PagesController < ApplicationController
  def about_us
  end

  def contact_us
  end

  def privacy_policy
  end

  def terms_and_conditions
  end
end
