class DocumentsController < ApplicationController

	

end