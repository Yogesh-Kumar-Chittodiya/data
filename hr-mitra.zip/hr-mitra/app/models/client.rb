class Client < ApplicationRecord
end