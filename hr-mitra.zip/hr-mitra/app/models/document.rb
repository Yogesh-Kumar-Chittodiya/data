class Document < ApplicationRecord
  belongs_to :employee
end
