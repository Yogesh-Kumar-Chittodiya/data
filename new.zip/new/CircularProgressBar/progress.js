const num=document.querySelector(".number");

const numVal1 = Number(num.getAttribute('data-value'));

let counter = 0;
setInterval(()=>{
    if(counter!=numval1){
        counter++;
        num.innerHtml='$(counter)%'
    }
},80)