function change(){
    // const a = document.getElementsByClassName("ring");
    const a = document.getElementById("2");
    const b = document.getElementById("3");
    const c = document.getElementById("4");

    // c.style.transform.rotate=360;
    // a.style.backgroundColor="yellow";
    b.style.borderColor="red";
    a.style.borderColor="blue";
    // c.style.borderTopColor ="white";
    // c.style.borderBottomColor="white";

    // c.style.borderBottomWidth="0";
    c.style.borderWidth="0";
    

    a.style.transform='rotate(3200deg)';
    a.style.transition='10s';

    b.style.transform='rotate(-3200deg)';
    b.style.transition='10s';

    c.style.transform='rotate(3600deg)';
    c.style.transition='8s';

    // b.style.transform.rotate("360deg");
    // c.style.backgroundColor="red";
}

function change1(){
    // const a = document.getElementsByClassName("ring");
    const a = document.getElementById("two");
    const b = document.getElementById("three");
    const c = document.getElementById("four");

    // c.style.transform.rotate=360;
    // a.style.backgroundColor="yellow";
    b.style.borderColor="red";
    a.style.borderColor="blue";

    c.style.borderTopColor="green";
    c.style.borderBottomColor="green";

    a.style.transform='rotate(3600deg)';
    a.style.transition='10s';

    b.style.transform='rotate(-3650deg)';
    b.style.transition='10s';

    c.style.transform='rotate(3600deg)';
    c.style.transition='10s';

    // b.style.transform.rotate("360deg");
    // c.style.backgroundColor="red";
}