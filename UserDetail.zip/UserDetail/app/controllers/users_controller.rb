class UsersController < ApplicationController
  
  def index
  end

  def edit
  end

  def delete
  end

  def update
  end

  def show
  end
end
