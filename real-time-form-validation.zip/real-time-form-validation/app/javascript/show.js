
// function chang(){
//     // const data = document.getElementsByClassName('Data');

//     const ring1 =document.getElementById("1")
//     const ring2 =document.getElementById("2");
//     const ring3 =document.getElementById("3");

//     ring1.style.border="red";
//     ring2.style.border="blue";
//     ring3.style.border="green";

// }
