// Entry point for the build script in your package.json
// import "./show"
import "@hotwired/turbo-rails"
import "./controllers"
import * as bootstrap from "bootstrap"

