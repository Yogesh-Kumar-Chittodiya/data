(() => {
})();
//# sourceMappingURL=/assets/application.js.map
