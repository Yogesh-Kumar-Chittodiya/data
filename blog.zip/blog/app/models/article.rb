# Reference : https://guides.rubyonrails.org/getting_started.html

class Article < ApplicationRecord
    validates :title, presence: true
    validates :body, presence: true, length: {minimum: 10}
end
