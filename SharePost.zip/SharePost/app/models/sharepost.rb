class Sharepost < ApplicationRecord
    
end
