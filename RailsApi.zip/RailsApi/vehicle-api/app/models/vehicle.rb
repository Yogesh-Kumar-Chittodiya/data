class Vehicle < ApplicationRecord
end
